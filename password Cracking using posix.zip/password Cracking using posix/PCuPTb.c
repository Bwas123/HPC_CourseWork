#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>
#include <time.h>

/***********************************************************************
*******

  Compile with:

    cc -o PCuPTb PCuPTb.c -lcrypt

  Run with:

    ./PCuPTb > results.txt


************************************************************************
******/


int n_passwords = 4;

char *encrypted_passwords[] = {

"$6$KB$YdKkNvrxK8t3tZGYZ7S8s8M/l/0.8udJLHgU2Mv4arpPhNz3Wkc4Ai7WPjZ00BWvtVZDIzHCvXnf4qkpjji981",

"$6$KB$Tv3kkEqvpiEVKpdyYFmAJrMryENHcd0xexew7uzN1El0cQJbT/TJpt7TWFYccd8VYbvauKxHuM9MkHoSMuBNn0",

"$6$KB$L.L7pt7V1XmzUbRh7C7oESIGtUN5pFzckZQBAF6MP1U9N28HcRBQ9xFenuvOEkA8IZHtYms/TFd.AEySP77Kp.",

"$6$KB$sUxYOvHNE1lxMpR/WR3asn.E/7VrOH3m3p3lf7RYnO1F5bppFDsMTN3Jw7eCw2i9Zsy7zqvSLK/kCb9xFhpgX1"
};

/**
 Required by lack of standard function in C.   
*/

void substr(char *dest, char *src, int start, int length)
{
	  memcpy(dest, src + start, length);
	  *(dest + length) = '\0';
}


/**
 This function can crack the kind of password explained above. All
combinations
 that are tried are displayed and when the password is found, #, is put
at the
 start of the line. Note that one of the most time consuming operations
that
 it performs is the output of intermediate results, so performance
experiments
 for this kind of program should not include this. i.e. comment out the
printfs.
*/


void crack(char *salt_and_encrypted)
{
  int x, y, r, z;                // Loop counters
  char salt[7];                  // String used in hashing the password. Need space
  char plain[7];                 // The combination of letters currently being checked
  char *enc;                     // Pointer to the encrypted password
  int count = 0;                 // The number of combinations explored so far


  substr(salt, salt_and_encrypted, 0, 6);
  
	 for(x='A'; x<='Z'; x++)
	{
    		for(y='A'; y<='Z'; y++)
		{
			for(r='A'; r<='Z'; r++)
			{
	      			for(z=0; z<=99; z++)
				{

					sprintf(plain, "%c%c%c%02d", x, y, r, z);
					enc = (char *) crypt(plain, salt);
					count++;

					if(strcmp(salt_and_encrypted, enc) == 0)
					{
					  printf("#%-8d%s %s\n", count, plain, enc);
					} 

					else 
					{
					  printf(" %-8d%s %s\n", count, plain, enc);
					}
				}
	      		}
	   	 }
	  }

  printf("%d solutions explored\n", count);
}


//Calculating time

int time_difference(struct timespec *start, struct timespec *finish, long long int *difference)
 {
	  long long int ds =  finish->tv_sec - start->tv_sec; 
	  long long int dn =  finish->tv_nsec - start->tv_nsec; 

	  if(dn < 0 ) 
	  {
	    ds--;
	    dn += 1000000000; 
          } 

	  *difference = ds * 1000000000 + dn;
	  return !(*difference > 0);
}

int main(int argc, char *argv[])
{
  	int i;
	struct timespec start, finish;   
  	long long int time_elapsed;

  	clock_gettime(CLOCK_MONOTONIC, &start);

  	for(i=0;i<n_passwords;i<i++) 
	{
    		crack(encrypted_passwords[i]);
  	}
	clock_gettime(CLOCK_MONOTONIC, &finish);
	  time_difference(&start, &finish, &time_elapsed);
	  printf("Time elapsed was %lldns or %0.9lfs\n", time_elapsed,
		                                 (time_elapsed/1.0e9)); 
  return 0;
}
